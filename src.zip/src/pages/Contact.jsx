function Contact() {
    return (
      <div>
        <h1>Contact Us</h1>
        <p>Have any questions? Reach out to us anytime!</p>
        <p>Email: support@mystore.com</p>
        <p>Phone: +123-456-7890</p>
      </div>
    );
  }
  
  export default Contact;
  