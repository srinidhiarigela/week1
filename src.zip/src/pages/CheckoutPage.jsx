function CheckoutPage() {
    return (
      <div>
        <h1>Secure Checkout</h1>
        <p>Complete your purchase safely and securely.</p>
        <p>We accept all major payment methods including credit/debit cards and PayPal.</p>
      </div>
    );
  }
  
  export default CheckoutPage;
  