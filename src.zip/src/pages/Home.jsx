function Home() {
    return (
      <div>
        <h1>Welcome to My Awesome Store</h1>
        <p>Your one-stop destination for quality products at unbeatable prices.</p>
        <p>Explore our wide range of electronics, fashion, and home essentials.</p>
      </div>
    );
  }
  
  export default Home;
  