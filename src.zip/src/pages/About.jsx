function About() {
    return (
      <div>
        <h1>About Us</h1>
        <p>We are committed to providing the best products and services to our customers.</p>
        <p>Our mission is to make shopping easy, affordable, and enjoyable.</p>
      </div>
    );
  }
  
  export default About;
  